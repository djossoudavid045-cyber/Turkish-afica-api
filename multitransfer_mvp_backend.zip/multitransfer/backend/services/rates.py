"""Service de taux de change avec fallback local."""
from decimal import Decimal

import httpx

from config import settings


class ExchangeRateService:
    FALLBACK_RATES = {
        "EUR": {"XOF": Decimal("655.957"), "XAF": Decimal("655.957"), "NGN": Decimal("1680.00"), "TRY": Decimal("42.50")},
        "TRY": {"EUR": Decimal("0.0235"), "XOF": Decimal("15.40"), "NGN": Decimal("39.50")},
        "XOF": {"EUR": Decimal("0.001524"), "TRY": Decimal("0.0649")},
        "NGN": {"EUR": Decimal("0.000595"), "TRY": Decimal("0.0253")},
    }

    async def get_rate(self, source_currency: str, target_currency: str) -> Decimal:
        source_currency = source_currency.upper()
        target_currency = target_currency.upper()

        if source_currency == target_currency:
            return Decimal("1")

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(f"{settings.EXCHANGE_RATE_API_URL}/{source_currency}")
                response.raise_for_status()
                data = response.json()
                rates = data.get("rates") or {}
                if target_currency in rates:
                    return Decimal(str(rates[target_currency]))
        except Exception:
            if not settings.EXCHANGE_RATE_FALLBACK:
                raise

        try:
            return self.FALLBACK_RATES[source_currency][target_currency]
        except KeyError as exc:
            raise ValueError(f"Taux indisponible pour {source_currency}->{target_currency}") from exc
