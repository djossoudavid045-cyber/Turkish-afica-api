"""Service d'authentification - JWT, login, register et sécurité."""
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Optional, Tuple

from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from models.models import AuditLog, User, UserRole, UserStatus, Wallet

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class AuthService:
    def __init__(self, db: AsyncSession):
        self.db = db

    def hash_password(self, password: str) -> str:
        return pwd_context.hash(password)

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        return pwd_context.verify(plain_password, hashed_password)

    def create_access_token(self, user_id: str, role: str) -> str:
        now = datetime.now(timezone.utc)
        expires = now + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        payload = {
            "sub": str(user_id),
            "role": role,
            "exp": expires,
            "iat": now,
            "type": "access",
            "jti": str(uuid.uuid4()),
        }
        return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

    def create_refresh_token(self, user_id: str) -> str:
        now = datetime.now(timezone.utc)
        expires = now + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
        payload = {
            "sub": str(user_id),
            "exp": expires,
            "iat": now,
            "type": "refresh",
            "jti": str(uuid.uuid4()),
        }
        return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

    def create_token_pair(self, user: User) -> dict:
        role_value = user.role.value if hasattr(user.role, "value") else str(user.role)
        return {
            "access_token": self.create_access_token(str(user.id), role_value),
            "refresh_token": self.create_refresh_token(str(user.id)),
            "token_type": "bearer",
        }

    def decode_token(self, token: str) -> Optional[dict]:
        try:
            return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        except JWTError:
            return None

    async def authenticate_user(
        self, email: str, password: str, ip_address: str | None = None
    ) -> Tuple[Optional[User], Optional[str]]:
        result = await self.db.execute(select(User).where(or_(User.email == email, User.phone == email)))
        user = result.scalar_one_or_none()

        if not user:
            return None, "Email ou mot de passe incorrect"
        if user.status == UserStatus.BLOCKED:
            return None, "Votre compte a été bloqué pour raisons de sécurité"
        if user.status == UserStatus.SUSPENDED:
            return None, "Votre compte est suspendu. Contactez le support."

        now = datetime.now(timezone.utc)
        if user.locked_until and user.locked_until > now:
            remaining = user.locked_until - now
            return None, f"Compte verrouillé encore {int(remaining.total_seconds() // 60)} minutes"

        if not self.verify_password(password, user.password_hash):
            user.login_attempts = (user.login_attempts or 0) + 1
            if user.login_attempts >= 5:
                user.locked_until = now + timedelta(hours=1)
            await self._create_audit_log(user.id, "login_failed", "user", str(user.id), ip_address, False)
            await self.db.commit()
            return None, "Email ou mot de passe incorrect"

        user.login_attempts = 0
        user.locked_until = None
        user.last_login_at = now
        user.last_login_ip = ip_address

        await self._create_audit_log(user.id, "login", "user", str(user.id), ip_address, True)
        await self.db.commit()
        await self.db.refresh(user)
        return user, None

    async def register_user(
        self,
        first_name: str,
        last_name: str,
        email: str,
        phone: str,
        password: str,
        nationality: str | None = None,
        country_of_residence: str | None = None,
    ) -> Tuple[Optional[User], Optional[str]]:
        result = await self.db.execute(select(User).where(User.email == email))
        if result.scalar_one_or_none():
            return None, "Un compte avec cet email existe déjà"

        result = await self.db.execute(select(User).where(User.phone == phone))
        if result.scalar_one_or_none():
            return None, "Un compte avec ce numéro de téléphone existe déjà"

        if len(password) < 8:
            return None, "Le mot de passe doit contenir au moins 8 caractères"

        user = User(
            id=uuid.uuid4(),
            email=email,
            phone=phone,
            password_hash=self.hash_password(password),
            first_name=first_name,
            last_name=last_name,
            nationality=nationality,
            country_of_residence=country_of_residence,
            role=UserRole.CLIENT,
            status=UserStatus.ACTIVE,
            kyc_level="none",
            referral_code=self._generate_referral_code(),
            login_attempts=0,
        )

        self.db.add(user)
        await self.db.flush()

        default_wallets = ["EUR", "TRY"]
        if country_of_residence:
            default_currency = settings.COUNTRY_CURRENCIES.get(country_of_residence)
            if default_currency and default_currency not in default_wallets:
                default_wallets.append(default_currency)

        for currency in set(default_wallets):
            self.db.add(
                Wallet(
                    user_id=user.id,
                    currency=currency,
                    balance=Decimal("0.0000"),
                    blocked_balance=Decimal("0.0000"),
                )
            )

        await self._create_audit_log(user.id, "register", "user", str(user.id), None, True)
        await self.db.commit()
        await self.db.refresh(user)
        return user, None

    async def get_user_from_token(
        self, token: str, expected_type: str = "access"
    ) -> Tuple[Optional[User], Optional[str]]:
        payload = self.decode_token(token)
        if not payload:
            return None, "Token invalide ou expiré"

        token_type = payload.get("type")
        if token_type != expected_type:
            return None, "Type de token invalide"

        user_id = payload.get("sub")
        if not user_id:
            return None, "Token invalide"

        result = await self.db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if not user:
            return None, "Utilisateur introuvable"
        if user.status != UserStatus.ACTIVE:
            return None, "Compte inactif"
        return user, None

    async def refresh_access_token(self, refresh_token: str) -> Tuple[Optional[str], Optional[str]]:
        user, error = await self.get_user_from_token(refresh_token, expected_type="refresh")
        if error:
            return None, error
        role_value = user.role.value if hasattr(user.role, "value") else str(user.role)
        return self.create_access_token(str(user.id), role_value), None

    async def change_password(self, user: User, current_password: str, new_password: str) -> Optional[str]:
        if not self.verify_password(current_password, user.password_hash):
            return "Mot de passe actuel incorrect"
        if len(new_password) < 8:
            return "Le nouveau mot de passe doit contenir au moins 8 caractères"

        user.password_hash = self.hash_password(new_password)
        user.login_attempts = 0
        user.locked_until = None
        await self._create_audit_log(user.id, "change_password", "user", str(user.id), None, True)
        await self.db.commit()
        return None

    async def _create_audit_log(
        self,
        user_id,
        action: str,
        resource_type: str,
        resource_id: str | None,
        ip_address: str | None,
        success: bool,
        details: str | None = None,
    ) -> None:
        self.db.add(
            AuditLog(
                user_id=user_id,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                ip_address=ip_address,
                success=success,
                details=details,
            )
        )

    def _generate_referral_code(self) -> str:
        return uuid.uuid4().hex[:10].upper()
