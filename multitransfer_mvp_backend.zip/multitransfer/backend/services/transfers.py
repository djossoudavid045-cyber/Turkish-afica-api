"""Moteur de calcul et création de transferts."""
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from models.models import AuditLog, TransactionStatus, TransferTransaction, User, UserRole
from services.rates import ExchangeRateService


@dataclass
class TransferQuoteResult:
    source_amount: Decimal
    source_currency: str
    target_amount: Decimal
    target_currency: str
    fee_amount: Decimal
    partner_commission: Decimal
    fx_rate: Decimal
    fx_margin_percent: Decimal
    payment_rail: str
    requires_kyc: bool
    estimated_settlement_minutes: int


class TransferService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.rate_service = ExchangeRateService()

    async def generate_quote(
        self,
        amount: Decimal,
        source_currency: str,
        target_currency: str,
        payment_rail: str,
        source_country: str,
        target_country: str,
        user: User,
    ) -> TransferQuoteResult:
        source_currency = source_currency.upper()
        target_currency = target_currency.upper()
        source_country = source_country.upper()
        target_country = target_country.upper()

        self._validate_currency(source_currency)
        self._validate_currency(target_currency)
        rail_config = self._validate_payment_rail(payment_rail, target_currency, target_country)
        self._validate_corridor(source_country, target_country)

        minimum = Decimal(str(settings.MIN_TRANSFER_AMOUNT_EUR))
        maximum = Decimal(str(settings.MAX_TRANSFER_AMOUNT_EUR))
        if amount < minimum:
            raise ValueError(f"Le montant minimum est {minimum} EUR équivalent")
        if amount > maximum:
            raise ValueError(f"Le montant maximum est {maximum} EUR équivalent")

        today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        result = await self.db.execute(
            select(func.coalesce(func.sum(TransferTransaction.source_amount), 0)).where(
                TransferTransaction.user_id == user.id,
                TransferTransaction.created_at >= today_start,
                TransferTransaction.status.in_([
                    TransactionStatus.PENDING,
                    TransactionStatus.PROCESSING,
                    TransactionStatus.COMPLETED,
                ]),
            )
        )
        daily_total = Decimal(str(result.scalar_one() or 0))
        if daily_total + amount > Decimal(str(settings.DAILY_LIMIT_EUR)):
            raise ValueError("Limite journalière dépassée")

        raw_rate = await self.rate_service.get_rate(source_currency, target_currency)
        fx_margin_percent = Decimal(str(settings.FX_MARGIN_PERCENT))
        effective_rate = raw_rate * (Decimal("1") - fx_margin_percent / Decimal("100"))

        percentage_fee = amount * Decimal(str(settings.FEE_PERCENTAGE)) / Decimal("100")
        min_fee = Decimal(str(settings.MIN_FEE_EUR))
        max_fee = Decimal(str(settings.MAX_FEE_EUR))
        fee_amount = min(max(percentage_fee, min_fee), max_fee)
        partner_commission = amount * Decimal(str(settings.PARTNER_COMMISSION_PERCENT)) / Decimal("100")
        sendable_amount = amount - fee_amount
        target_amount = (sendable_amount * effective_rate).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

        requires_kyc = amount >= Decimal(str(settings.KYC_REQUIRED_FOR_AMOUNT_EUR)) or user.kyc_level == "none"

        return TransferQuoteResult(
            source_amount=amount.quantize(Decimal("0.0001")),
            source_currency=source_currency,
            target_amount=target_amount,
            target_currency=target_currency,
            fee_amount=fee_amount.quantize(Decimal("0.0001")),
            partner_commission=partner_commission.quantize(Decimal("0.0001")),
            fx_rate=effective_rate.quantize(Decimal("0.00000001")),
            fx_margin_percent=fx_margin_percent,
            payment_rail=payment_rail,
            requires_kyc=requires_kyc,
            estimated_settlement_minutes=int(rail_config["settlement_time_minutes"]),
        )

    async def create_transfer(
        self,
        user: User,
        recipient_name: str,
        recipient_account_ref: str,
        amount: Decimal,
        source_currency: str,
        target_currency: str,
        payment_rail: str,
        source_country: str,
        target_country: str,
    ) -> TransferTransaction:
        quote = await self.generate_quote(
            amount=amount,
            source_currency=source_currency,
            target_currency=target_currency,
            payment_rail=payment_rail,
            source_country=source_country,
            target_country=target_country,
            user=user,
        )

        status = TransactionStatus.BLOCKED if quote.requires_kyc else TransactionStatus.PENDING
        note = "KYC requis avant exécution" if quote.requires_kyc else "En attente d'envoi vers le partenaire"

        transfer = TransferTransaction(
            user_id=user.id,
            external_reference=f"MT-{uuid.uuid4().hex[:12].upper()}",
            source_amount=quote.source_amount,
            source_currency=quote.source_currency,
            target_amount=quote.target_amount,
            target_currency=quote.target_currency,
            fx_rate=quote.fx_rate,
            fee_amount=quote.fee_amount,
            partner_commission=quote.partner_commission,
            payment_rail=payment_rail,
            source_country=source_country.upper(),
            target_country=target_country.upper(),
            recipient_name=recipient_name,
            recipient_account_ref=recipient_account_ref,
            compliance_note=note,
            requires_kyc=quote.requires_kyc,
            status=status,
        )
        self.db.add(transfer)
        self.db.add(
            AuditLog(
                user_id=user.id,
                action="create_transfer",
                resource_type="transfer",
                resource_id=None,
                success=True,
                details=f"rail={payment_rail}; requires_kyc={quote.requires_kyc}",
            )
        )
        await self.db.commit()
        await self.db.refresh(transfer)
        return transfer

    async def list_user_transfers(self, user: User) -> list[TransferTransaction]:
        result = await self.db.execute(
            select(TransferTransaction)
            .where(TransferTransaction.user_id == user.id)
            .order_by(TransferTransaction.created_at.desc())
        )
        return list(result.scalars().all())

    async def admin_dashboard(self) -> dict:
        total_result = await self.db.execute(select(func.count(TransferTransaction.id)))
        blocked_result = await self.db.execute(
            select(func.count(TransferTransaction.id)).where(TransferTransaction.status == TransactionStatus.BLOCKED)
        )
        pending_result = await self.db.execute(
            select(func.count(TransferTransaction.id)).where(TransferTransaction.status == TransactionStatus.PENDING)
        )
        revenue_result = await self.db.execute(select(func.coalesce(func.sum(TransferTransaction.fee_amount), 0)))

        return {
            "total_transfers": int(total_result.scalar_one() or 0),
            "blocked_transfers": int(blocked_result.scalar_one() or 0),
            "pending_transfers": int(pending_result.scalar_one() or 0),
            "estimated_fee_revenue": str(revenue_result.scalar_one() or 0),
            "corridors": settings.TARGET_CORRIDORS,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }

    def _validate_currency(self, currency: str) -> None:
        if currency not in settings.SUPPORTED_CURRENCIES:
            raise ValueError(f"Devise non supportée: {currency}")

    def _validate_payment_rail(self, payment_rail: str, target_currency: str, target_country: str) -> dict:
        rail_config = settings.SUPPORTED_PAYMENT_RAILS.get(payment_rail)
        if not rail_config:
            raise ValueError("Rail de paiement non supporté")
        if target_currency not in rail_config.get("currencies", []):
            raise ValueError("Ce rail ne supporte pas la devise cible sélectionnée")
        countries = rail_config.get("countries")
        if countries and target_country not in countries:
            raise ValueError("Ce rail ne supporte pas ce pays cible")
        return rail_config

    def _validate_corridor(self, source_country: str, target_country: str) -> None:
        corridor = f"{source_country}->{target_country}"
        if corridor not in settings.TARGET_CORRIDORS:
            if source_country == target_country:
                raise ValueError("Le corridor doit être international")
            allowed_sources = {"TR", "SN", "NG"}
            allowed_targets = {"SN", "NG", "FR", "DE"}
            if source_country not in allowed_sources or target_country not in allowed_targets:
                raise ValueError("Corridor non prioritaire pour le MVP")
