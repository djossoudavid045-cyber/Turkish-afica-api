from datetime import datetime
from decimal import Decimal
from pydantic import BaseModel, ConfigDict, Field

from models.models import TransactionStatus


class TransferQuoteRequest(BaseModel):
    amount: Decimal = Field(gt=0)
    source_currency: str = Field(min_length=3, max_length=10)
    target_currency: str = Field(min_length=3, max_length=10)
    payment_rail: str
    source_country: str = Field(min_length=2, max_length=2)
    target_country: str = Field(min_length=2, max_length=2)


class TransferQuoteResponse(BaseModel):
    source_amount: Decimal
    source_currency: str
    target_amount: Decimal
    target_currency: str
    fee_amount: Decimal
    partner_commission: Decimal
    fx_rate: Decimal
    fx_margin_percent: Decimal
    payment_rail: str
    requires_kyc: bool
    estimated_settlement_minutes: int


class CreateTransferRequest(TransferQuoteRequest):
    recipient_name: str = Field(min_length=2, max_length=255)
    recipient_account_ref: str = Field(min_length=4, max_length=255)


class TransferResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    external_reference: str
    source_amount: Decimal
    source_currency: str
    target_amount: Decimal
    target_currency: str
    fx_rate: Decimal
    fee_amount: Decimal
    partner_commission: Decimal
    payment_rail: str
    source_country: str
    target_country: str
    recipient_name: str
    recipient_account_ref: str
    compliance_note: str | None
    requires_kyc: bool
    status: TransactionStatus
    created_at: datetime


class AdminDashboardResponse(BaseModel):
    total_transfers: int
    blocked_transfers: int
    pending_transfers: int
    estimated_fee_revenue: str
    corridors: list[str]
    generated_at: str
