from datetime import datetime
from pydantic import BaseModel, ConfigDict, EmailStr, Field

from models.models import UserRole, UserStatus


class RegisterRequest(BaseModel):
    first_name: str = Field(min_length=2, max_length=100)
    last_name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    phone: str = Field(min_length=8, max_length=30)
    password: str = Field(min_length=8, max_length=128)
    nationality: str | None = Field(default=None, min_length=2, max_length=2)
    country_of_residence: str | None = Field(default=None, min_length=2, max_length=2)


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: EmailStr
    phone: str
    first_name: str
    last_name: str
    nationality: str | None
    country_of_residence: str | None
    role: UserRole
    status: UserStatus
    kyc_level: str
    referral_code: str
    created_at: datetime
