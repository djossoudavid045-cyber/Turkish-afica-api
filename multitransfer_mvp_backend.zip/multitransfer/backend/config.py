"""Configuration centralisée de l'application MultiTransfer."""
from typing import Dict, List, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", case_sensitive=True, extra="ignore")

    APP_NAME: str = "MultiTransfer API"
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = Field("development")
    DEBUG: bool = Field(True)
    ALLOWED_ORIGINS: str = Field("http://localhost,http://localhost:3000,http://localhost:5173")

    SECRET_KEY: str = Field(...)
    ALGORITHM: str = Field("HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(60)
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(7)
    BCRYPT_ROUNDS: int = 12

    DATABASE_URL: str = Field(...)
    REDIS_URL: str = Field("redis://localhost:6379/0")

    EXCHANGE_RATE_API_KEY: Optional[str] = Field(None)
    EXCHANGE_RATE_API_URL: str = Field("https://open.er-api.com/v6/latest")
    EXCHANGE_RATE_FALLBACK: bool = True
    FX_MARGIN_PERCENT: float = Field(1.25)

    MAX_TRANSFER_AMOUNT_EUR: float = Field(10000)
    MIN_TRANSFER_AMOUNT_EUR: float = Field(10)
    DAILY_LIMIT_EUR: float = Field(25000)

    FEE_PERCENTAGE: float = Field(2.5)
    MIN_FEE_EUR: float = Field(0.50)
    MAX_FEE_EUR: float = Field(50.00)
    PARTNER_COMMISSION_PERCENT: float = Field(0.5)

    KYC_REQUIRED_FOR_AMOUNT_EUR: float = Field(500)
    KYC_DOCUMENTS_PATH: str = Field("./uploads/kyc")

    SUPPORTED_PAYMENT_RAILS: Dict[str, dict] = {
        "sepa": {
            "name": "SEPA Transfer",
            "regions": ["EU"],
            "currencies": ["EUR"],
            "max_amount": 50000,
            "settlement_time_minutes": 24 * 60,
        },
        "swift": {
            "name": "SWIFT International",
            "regions": ["ALL"],
            "currencies": ["EUR", "USD", "TRY", "XOF", "XAF", "NGN", "KES", "GHS", "MAD", "ZAR", "EGP", "TND", "DZD"],
            "max_amount": 100000,
            "settlement_time_minutes": 3 * 24 * 60,
        },
        "mobile_money_mtn": {
            "name": "MTN Mobile Money",
            "regions": ["AFRICA"],
            "countries": ["CI", "SN", "BJ", "ML", "NE", "BF", "TG", "GN", "GH", "CM", "UG", "RW", "ZM", "CD"],
            "currencies": ["XOF", "GHS", "UGX", "RWF", "ZMW", "CDF"],
            "max_amount": 5000,
            "settlement_time_minutes": 30,
        },
        "mobile_money_orange": {
            "name": "Orange Money",
            "regions": ["AFRICA"],
            "countries": ["CI", "SN", "ML", "BF", "TG", "NE", "CM", "MG", "MR"],
            "currencies": ["XOF", "XAF", "MGA", "MRU"],
            "max_amount": 3000,
            "settlement_time_minutes": 15,
        },
        "mpesa": {
            "name": "M-Pesa",
            "regions": ["AFRICA"],
            "countries": ["KE", "TZ", "UG", "RW", "ZM", "CD", "GH", "LS", "SZ"],
            "currencies": ["KES", "TZS", "UGX", "RWF", "ZMW", "CDF", "GHS", "LSL", "SZL"],
            "max_amount": 5000,
            "settlement_time_minutes": 5,
        },
        "bank_transfer": {
            "name": "Bank Transfer",
            "regions": ["ALL"],
            "currencies": ["EUR", "USD", "TRY", "MAD", "ZAR", "EGP", "TND", "DZD", "XOF", "XAF", "NGN", "KES", "GHS"],
            "max_amount": 50000,
            "settlement_time_minutes": 2 * 24 * 60,
        },
        "cash_pickup": {
            "name": "Cash Pickup",
            "regions": ["AFRICA", "TURKEY"],
            "countries": ["TR", "SN", "CI", "ML", "NE", "BF", "CM", "KE", "NG", "GH", "MA", "TN", "DZ", "EG", "ZA"],
            "currencies": ["TRY", "XOF", "XAF", "KES", "NGN", "GHS", "MAD", "TND", "DZD", "EGP", "ZAR"],
            "max_amount": 3000,
            "settlement_time_minutes": 60,
        },
    }

    SUPPORTED_CURRENCIES: Dict[str, dict] = {
        "TRY": {"name": "Turkish Lira", "symbol": "₺", "decimals": 2, "region": "TR"},
        "EUR": {"name": "Euro", "symbol": "€", "decimals": 2, "region": "EU"},
        "USD": {"name": "US Dollar", "symbol": "$", "decimals": 2, "region": "INT"},
        "XOF": {"name": "CFA Franc BCEAO", "symbol": "CFA", "decimals": 0, "region": "AFRICA", "zone": "UEMOA"},
        "XAF": {"name": "CFA Franc BEAC", "symbol": "CFA", "decimals": 0, "region": "AFRICA", "zone": "CEMAC"},
        "NGN": {"name": "Nigerian Naira", "symbol": "₦", "decimals": 2, "region": "AFRICA"},
        "KES": {"name": "Kenyan Shilling", "symbol": "KSh", "decimals": 2, "region": "AFRICA"},
        "GHS": {"name": "Ghanaian Cedi", "symbol": "GH₵", "decimals": 2, "region": "AFRICA"},
        "MAD": {"name": "Moroccan Dirham", "symbol": "DH", "decimals": 2, "region": "AFRICA"},
        "ZAR": {"name": "South African Rand", "symbol": "R", "decimals": 2, "region": "AFRICA"},
        "EGP": {"name": "Egyptian Pound", "symbol": "E£", "decimals": 2, "region": "AFRICA"},
        "TND": {"name": "Tunisian Dinar", "symbol": "DT", "decimals": 3, "region": "AFRICA"},
        "DZD": {"name": "Algerian Dinar", "symbol": "DA", "decimals": 2, "region": "AFRICA"},
    }

    COUNTRY_CURRENCIES: Dict[str, str] = {
        "TR": "TRY",
        "FR": "EUR", "DE": "EUR", "IT": "EUR", "ES": "EUR", "PT": "EUR", "NL": "EUR", "BE": "EUR", "GR": "EUR",
        "AT": "EUR", "IE": "EUR", "FI": "EUR", "SK": "EUR", "SI": "EUR", "LT": "EUR", "LV": "EUR", "EE": "EUR",
        "LU": "EUR", "MT": "EUR", "CY": "EUR", "HR": "EUR",
        "CI": "XOF", "SN": "XOF", "BJ": "XOF", "ML": "XOF", "NE": "XOF", "BF": "XOF", "TG": "XOF", "GN": "XOF",
        "CM": "XAF", "GA": "XAF", "CG": "XAF", "TD": "XAF", "CF": "XAF", "GQ": "XAF",
        "NG": "NGN", "KE": "KES", "GH": "GHS", "MA": "MAD", "ZA": "ZAR", "EG": "EGP", "TN": "TND", "DZ": "DZD",
    }

    TARGET_CORRIDORS: List[str] = [
        "TR->SN",
        "TR->NG",
        "SN->FR",
        "NG->DE",
        "TR->FR",
    ]

    @property
    def allowed_origins_list(self) -> List[str]:
        return [origin.strip() for origin in self.ALLOWED_ORIGINS.split(",") if origin.strip()]


settings = Settings()
