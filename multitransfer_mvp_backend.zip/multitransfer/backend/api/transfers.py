from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status

from api.deps import DbSession, get_current_user
from models.models import User
from schemas.transfers import (
    CreateTransferRequest,
    TransferQuoteRequest,
    TransferQuoteResponse,
    TransferResponse,
)
from services.transfers import TransferService

router = APIRouter(prefix="/api/v1/transfers", tags=["transfers"])


@router.post("/quote", response_model=TransferQuoteResponse)
async def quote(
    payload: TransferQuoteRequest,
    db: DbSession,
    current_user: Annotated[User, Depends(get_current_user)],
):
    service = TransferService(db)
    try:
        quote_result = await service.generate_quote(user=current_user, **payload.model_dump())
        return TransferQuoteResponse(**quote_result.__dict__)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.post("", response_model=TransferResponse, status_code=status.HTTP_201_CREATED)
async def create_transfer(
    payload: CreateTransferRequest,
    db: DbSession,
    current_user: Annotated[User, Depends(get_current_user)],
):
    service = TransferService(db)
    try:
        transfer = await service.create_transfer(user=current_user, **payload.model_dump())
        return transfer
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.get("", response_model=list[TransferResponse])
async def my_transfers(
    db: DbSession,
    current_user: Annotated[User, Depends(get_current_user)],
):
    service = TransferService(db)
    return await service.list_user_transfers(current_user)
