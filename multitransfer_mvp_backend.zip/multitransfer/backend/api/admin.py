from typing import Annotated

from fastapi import APIRouter, Depends

from api.deps import DbSession, get_admin_user
from models.models import User
from schemas.transfers import AdminDashboardResponse
from services.transfers import TransferService

router = APIRouter(prefix="/api/v1/admin", tags=["admin"])


@router.get("/dashboard", response_model=AdminDashboardResponse)
async def dashboard(
    db: DbSession,
    current_user: Annotated[User, Depends(get_admin_user)],
):
    service = TransferService(db)
    return await service.admin_dashboard()
