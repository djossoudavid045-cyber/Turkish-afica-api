from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status

from api.deps import DbSession, get_current_user
from models.models import User
from schemas.auth import ChangePasswordRequest, LoginRequest, RefreshRequest, RegisterRequest, TokenResponse, UserResponse
from services.auth import AuthService

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, db: DbSession):
    service = AuthService(db)
    user, error = await service.register_user(**payload.model_dump())
    if error or not user:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=error or "Échec de l'inscription")
    return user


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest, request: Request, db: DbSession):
    service = AuthService(db)
    user, error = await service.authenticate_user(
        email=payload.email,
        password=payload.password,
        ip_address=request.client.host if request.client else None,
    )
    if error or not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=error or "Identifiants invalides")
    return service.create_token_pair(user)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(payload: RefreshRequest, db: DbSession):
    service = AuthService(db)
    access_token, error = await service.refresh_access_token(payload.refresh_token)
    if error or not access_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=error or "Refresh token invalide")
    user, _ = await service.get_user_from_token(payload.refresh_token, expected_type="refresh")
    return {
        "access_token": access_token,
        "refresh_token": payload.refresh_token,
        "token_type": "bearer",
    }


@router.get("/me", response_model=UserResponse)
async def me(current_user: Annotated[User, Depends(get_current_user)]):
    return current_user


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT)
async def change_password(
    payload: ChangePasswordRequest,
    db: DbSession,
    current_user: Annotated[User, Depends(get_current_user)],
):
    service = AuthService(db)
    error = await service.change_password(current_user, payload.current_password, payload.new_password)
    if error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=error)
    return None
