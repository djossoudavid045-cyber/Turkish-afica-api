from typing import Annotated

from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from database import get_db
from models.models import User, UserRole
from services.auth import AuthService


DbSession = Annotated[AsyncSession, Depends(get_db)]


async def get_current_user(
    db: DbSession,
    authorization: Annotated[str | None, Header()] = None,
) -> User:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token manquant")
    token = authorization.split(" ", 1)[1].strip()
    service = AuthService(db)
    user, error = await service.get_user_from_token(token)
    if error or not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=error or "Non autorisé")
    return user


async def get_admin_user(current_user: Annotated[User, Depends(get_current_user)]) -> User:
    if current_user.role not in {UserRole.ADMIN, UserRole.COMPLIANCE}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Accès administrateur requis")
    return current_user
